﻿int number = int.Parse(Console.ReadLine());
Console.WriteLine(number + 10);
