﻿string name = Console.ReadLine();
string age = Console.ReadLine();
Console.WriteLine($"{name} e na {age} godini");
