﻿int a = int.Parse(Console.ReadLine());
int b = int.Parse(Console.ReadLine());
int c = int.Parse(Console.ReadLine());
int MaxNumber = Math.Max(a, b);
int MaximusNumber = Math.Max(MaxNumber, c);
Console.WriteLine($"{MaximusNumber} e nai-golqmoto chislo");