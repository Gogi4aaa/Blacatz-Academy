﻿int a = int.Parse(Console.ReadLine());
int b = int.Parse(Console.ReadLine());
int c = int.Parse(Console.ReadLine());
Console.WriteLine($"{Math.Sqrt(a + b + Math.Pow(c,2))}");