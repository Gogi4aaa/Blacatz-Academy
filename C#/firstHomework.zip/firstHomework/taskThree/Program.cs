﻿string strOne = Console.ReadLine();
string strTwo = Console.ReadLine();

int numOne = int.Parse(Console.ReadLine());
int numTwo = int.Parse(Console.ReadLine());

Console.WriteLine($"{strOne},{strTwo},{numOne + numTwo}");