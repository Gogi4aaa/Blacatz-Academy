﻿string input = Console.ReadLine();
if (input == "Pizza")
{
    Console.WriteLine("10lv");
}
else if(input == "Burger")
{
    Console.WriteLine("5lv");
}
else if(input == "Juice")
{
    Console.WriteLine("3lv");
}