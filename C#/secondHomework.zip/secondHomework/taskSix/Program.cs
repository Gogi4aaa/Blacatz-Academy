﻿string input = Console.ReadLine();

Console.WriteLine($"C:\\Users\\{input}\\AppData");